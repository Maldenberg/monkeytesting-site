const express = require("express");
const cors = require("cors"); // импортируем CORS
const app = express();
const port = 3000;

app.use(cors()); // использование CORS
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const fs = require("fs");
const { google } = require("googleapis");
const keys = require("./signinterview-a58d8fb907cf.json");

const client = new google.auth.JWT(keys.client_email, null, keys.private_key, [
  "https://www.googleapis.com/auth/spreadsheets",
]);

async function sendDataToGoogleSheet(data) {
  await client.authorize();

  const sheets = google.sheets({ version: "v4", auth: client });
  await sheets.spreadsheets.values.append({
    spreadsheetId: "1njNl2QSZ0H9DamWDafpxmx5KNvo6WUvOGyZk7oJQZgI",
    range: "Sheet1",
    valueInputOption: "RAW",
    resource: { values: [data] },
  });
}

app.post("/sendData", (req, res) => {
  const data = [
    req.body.lastName,
    req.body.firstName,
    req.body.middleName,
    req.body.travelDate,
    req.body.appointmenTime,
    req.body.phone,
    req.body.linkVk,
    req.body.company,
    req.body.linkVacancy,
    req.body.linkInterview,
    req.body.message,
  ];

  sendDataToGoogleSheet(data)
    .then(() => {
      res.status(200).send("Data sent to Google Sheet");
    })
    .catch((error) => {
      console.error("Error sending data to Google Sheet:", error);
      res.status(500).send("Internal Server Error");
    });
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
