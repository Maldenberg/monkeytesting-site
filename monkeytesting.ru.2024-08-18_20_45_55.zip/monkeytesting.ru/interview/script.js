async function downloadData() {
  try {
    var lastName = document.getElementById("lastName").value;
    var firstName = document.getElementById("firstName").value;
    var middleName = document.getElementById("middleName").value;
    var travelDate = document.getElementById("travel-date").value;
    var appointmenTime = document.getElementById("appointment-time").value;
    var phone = document.getElementById("phone").value;
    var linkVk = document.getElementById("link-vk").value;
    var company = document.getElementById("company").value;
    var linkVacancy = document.getElementById("link-vacancy").value;
    var linkInterview = document.getElementById("link-interview").value;
    var message = document.getElementById("message").value;

    var formattedData =
      "ФИО: " +
      lastName +
      " " +
      firstName +
      " " +
      middleName +
      "\n" +
      "Дата и время: " +
      travelDate +
      " " +
      appointmenTime +
      "\n" +
      "Телефон: " +
      phone +
      "\n" +
      "Ссылка на ВК: " +
      linkVk +
      "\n" +
      "Компания: " +
      company +
      "\n" +
      "Ссылка на вакансию: " +
      linkVacancy +
      "\n" +
      "Ссылка на собес: " +
      linkInterview +
      "\n" +
      "Доп. инфа: " +
      message +
      "\n";

    var fileName =
      "Запись на собес_" +
      lastName +
      "-" +
      travelDate +
      " " +
      appointmenTime +
      ".txt";

    // Создаем новый элемент ссылки
    var link = document.createElement("a");
    link.download = fileName;
    link.href = "data:text/plain," + encodeURIComponent(formattedData);
    link.style.display = "none";

    // Добавляем ссылку на страницу и скачиваем файл
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    // Отправка данных в Telegram
    var telegramUrl =
      "https://api.telegram.org/bot6059408500:AAHEHHEuX82YjH6_phc9PodInsRoql3habk/sendMessage";
    var telegramData = {
      chat_id: "-1001793764086",
      text: formattedData,
      parse_mode: "HTML",
    };

    let telegramResponse = await fetch(telegramUrl, {
      method: "POST",
      body: JSON.stringify(telegramData),
      headers: {
        "Content-Type": "application/json",
      },
    });
    let telegramResult = await telegramResponse.json();
    console.log(telegramResult);

    // Отправка данных на ваш сервер
    let serverData = {
      lastName,
      firstName,
      middleName,
      travelDate,
      appointmenTime,
      phone,
      linkVk,
      company,
      linkVacancy,
      linkInterview,
      message,
    };

    let serverResponse = await fetch("/sendData", {
      method: "POST",
      body: JSON.stringify(serverData),
      headers: {
        "Content-Type": "application/json",
      },
    });

    if (serverResponse.ok) {
      console.log("Data successfully sent to the server");
    } else {
      console.log("Failed to send data to the server");
    }
  } catch (error) {
    console.error("Ошибка:", error);
  }
}
