const { google } = require("googleapis");
const keys = require("./signinterview-a58d8fb907cf.json");

const client = new google.auth.JWT(keys.client_email, null, keys.private_key, [
  "https://www.googleapis.com/auth/spreadsheets",
]);

client.authorize(function (err, tokens) {
  if (err) {
    console.log(err);
    return;
  } else {
    console.log("Connected to Google Sheets API");
    gsrun(client);
  }
});

async function gsrun(cl) {
  const gsapi = google.sheets({ version: "v4", auth: cl });
  const opt = {
    spreadsheetId: "1njNl2QSZ0H9DamWDafpxmx5KNvo6WUvOGyZk7oJQZgI",
    range: "Sheet1!A2", // Укажите нужный лист и ячейку
  };

  // В этом месте можно добавить код для записи в таблицу
  let data = [["Тестовые", "данные"]]; // Пример данных
  const updateOptions = {
    spreadsheetId: "1njNl2QSZ0H9DamWDafpxmx5KNvo6WUvOGyZk7oJQZgI",
    range: "Sheet1!A2", // Update this range of cells.
    valueInputOption: "USER_ENTERED",
    resource: {
      values: data,
    },
  };

  let res = await gsapi.spreadsheets.values.update(updateOptions);
  console.log(res.data);
}
